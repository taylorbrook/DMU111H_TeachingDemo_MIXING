
The following samples files are derived from test files distributed with ALSA
------------------------------------

See https://www.debian.org/license for details


License details
------------------------------------

ALSA files under Debian Linux. License: SPI / GPL. This content is excluded from our Creative Commons license. For more information, see https://ocw.mit.edu/help/faq-fair-use/.


Sample files
------------------------------------

   * in1.wav
   * in2.wav
   * in.wav
   * left.wav
   * mono.wav
   * right.wav
   * stereo.wav
